<?php require_once("includes/header.php"); ?>

  <div class="container">
    <h3 class="alert alert-info">Estatísticas aqui</h3>
    <hr>

  </div>

<?php require_once("includes/footer.php"); ?>
